# Beytülmakdis Yolculuğu — Kurulum Rehberi

Bu klasördeki tüm dosyalar, hiçbir sunucu kodu (PHP, veritabanı vb.) gerektirmeyen
statik bir web sitesidir. GitHub Pages, Netlify veya Cloudflare Pages gibi
ücretsiz servislerde doğrudan yayınlanabilir.

## Klasör yapısı

```
index.html          → Ana sayfa
tarih.html           → Tarih Yolculuğu (zaman tüneli)
tur.html              → Aksa Turu & interaktif harita
peygamberler.html     → Peygamberler
oyunlar.html          → Bilgi yarışması / Doğru-Yanlış / Hafıza oyunu
hikayeler.html        → Yaşa özel hikayeler
sozluk.html           → Terimler sözlüğü
boyama.html           → Yazdırılabilir boyama sayfaları
videolar.html         → Video ders alanı (şimdilik "yakında")
rehber.html           → Ebeveyn & öğretmen rehberi
assets/style.css      → Tüm sayfaların ortak tasarımı
assets/data.js        → Tüm metinler, sorular, sözlük, hikayeler BURADA
assets/app.js         → Site mantığı (oyunlar, ilerleme, harita vb.)
```

## İçeriği düzenlemek

Neredeyse tüm metinleri **tek bir dosyada**, `assets/data.js` içinde bulursun.
Yaş gruplarına göre ayrılmış metinleri (`k`, `c`, `t`, `y`) değiştirmen yeterli;
tüm sayfalar otomatik güncellenir.

## Destek / bağış butonunu ayarlama

`assets/data.js` dosyasının en üstünde şu satırı bulup kendi
Buy Me a Coffee / Ko-fi linkinle değiştir:

```js
const SUPPORT_URL = "https://www.buymeacoffee.com/kullaniciadin";
```

Bu tek değişiklik, tüm sayfalardaki "☕ Bizi Destekle" butonunu otomatik günceller.

## GitHub Pages ile yayınlama

1. GitHub'da yeni bir depo (repository) oluştur.
2. Bu klasördeki **tüm dosya ve klasörleri** (assets dahil) depoya yükle
   ("Add file > Upload files").
3. Depo **Settings > Pages** bölümüne git, "Branch" olarak `main` (veya `master`)
   ve `/ (root)` seç, kaydet.
4. Birkaç dakika içinde `kullaniciadi.github.io/depo-adi` şeklinde bir link
   üretilir.
5. Kendi alan adını bağlamak istersen, aynı sayfadaki "Custom domain" alanına
   domainini yaz ve registrarının DNS panelinden istenen CNAME kaydını ekle.

## Notlar

- İlerleme/yıldız/rozet verileri her ziyaretçinin kendi tarayıcısında
  (localStorage) tutulur; herkese ortak bir puan tablosu değildir.
- Boyama sayfaları tamamen özgün SVG çizimlerdir, telif sorunu taşımaz.
- Harita, gerçek coğrafi/siyasi bir harita değil, Mescid-i Aksa külliyesinin
  basitleştirilmiş, özgün bir illüstrasyonudur.
