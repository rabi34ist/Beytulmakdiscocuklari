/* ===========================================================
   Beytülmakdis Yolculuğu — Paylaşılan Uygulama Mantığı
   =========================================================== */
const state = {
  tier: localStorage.getItem('bm_tier') || 'c',
  game: 'quiz',
  quizIndex: 0,
  quizAnswered: false,
  tfIndex: 0,
  tfAnswered: false,
  memFlipped: [],
  memMatched: [],
  memLock: false
};

/* ---------- LAYOUT (header/nav shared across pages) ---------- */
function buildTierPicker(){
  const tp = document.getElementById('tierPicker');
  if(!tp) return;
  tp.innerHTML = TIERS.map(t => `<button class="tier-btn" id="tierbtn-${t.id}" onclick="setTier('${t.id}')">${t.emoji} ${t.short}</button>`).join('');
  updateTierUI();
}

function setTier(tier){
  state.tier = tier;
  localStorage.setItem('bm_tier', tier);
  updateTierUI();
  if(typeof renderPageContent === 'function') renderPageContent();
}

function updateTierUI(){
  TIERS.forEach(t=>{
    const btn = document.getElementById('tierbtn-'+t.id);
    if(btn) btn.classList.toggle('active', t.id===state.tier);
    const card = document.getElementById('agecard-'+t.id);
    if(card) card.classList.toggle('active', t.id===state.tier);
  });
}

function buildAgeGrid(){
  const ag = document.getElementById('ageGrid');
  if(!ag) return;
  ag.innerHTML = TIERS.map(t => `
    <div class="age-card" id="agecard-${t.id}" onclick="setTier('${t.id}')" role="button" tabindex="0">
      <div class="emoji">${t.emoji}</div>
      <h3>${t.short}</h3>
      <p>${t.label}</p>
    </div>`).join('');
  updateTierUI();
}

/* ---------- PROGRESS / LEVEL SYSTEM ---------- */
function markVisited(sec){
  let v = JSON.parse(localStorage.getItem('bm_visited')||'[]');
  if(!v.includes(sec)){ v.push(sec); localStorage.setItem('bm_visited', JSON.stringify(v)); }
}
function getStars(){ return parseInt(localStorage.getItem('bm_stars')||'0', 10); }
function addStar(){ localStorage.setItem('bm_stars', String(getStars()+1)); renderProgress(); }

function getLevel(stars){
  if(stars >= 20) return {name:'Beytülmakdis Dostu', emoji:'🌟'};
  if(stars >= 12) return {name:'Bilge Kâşif', emoji:'📚'};
  if(stars >= 6) return {name:'Kâşif', emoji:'🧭'};
  return {name:'Yavru Kâşif', emoji:'🐣'};
}

function renderProgress(){
  const fill = document.getElementById('progressFill');
  const starsText = document.getElementById('starsText');
  if(!fill || !starsText) return;
  const total = 10; // toplam sayfa sayısı
  const v = JSON.parse(localStorage.getItem('bm_visited')||'[]');
  const pct = Math.min(100, Math.round((v.length/total)*100));
  fill.style.width = pct+'%';
  const stars = getStars();
  const lvl = getLevel(stars);
  starsText.innerHTML = `⭐ ${stars} doğru cevap &nbsp;·&nbsp; <span class="level-badge">${lvl.emoji} ${lvl.name}</span>`;
}

/* ---------- GENERIC RENDERERS (called from individual pages) ---------- */
function renderTimeline(){
  const box = document.getElementById('timelineBox');
  if(!box) return;
  box.innerHTML = HISTORY.map(item => `
    <div class="tl-item">
      <div class="tl-dot">${item.icon}</div>
      <div class="tl-card">
        <div class="yr">${item.year}</div>
        <h4>${item.title}</h4>
        <p>${item.text[state.tier]}</p>
      </div>
    </div>`).join('');
}

function renderTourCards(){
  const box = document.getElementById('tourGrid');
  if(!box) return;
  box.innerHTML = TOUR.map(item => `
    <div class="info-card">
      <div class="emoji">${item.icon}</div>
      <h3>${item.name}</h3>
      <p>${item.text[state.tier]}</p>
    </div>`).join('');
}

function renderProphets(){
  const box = document.getElementById('prophetsGrid');
  if(!box) return;
  box.innerHTML = PROPHETS.map(item => `
    <div class="info-card">
      <div class="emoji">${item.icon}</div>
      <h3>${item.name}</h3>
      <p>${item.text[state.tier]}</p>
    </div>`).join('');
}

function renderStoryBox(){
  const box = document.getElementById('storyBox');
  if(!box) return;
  const s = STORIES[state.tier];
  box.innerHTML = `<h3>${s.title}</h3><p>${s.text}</p>`;
}

function renderGlossary(){
  const box = document.getElementById('glossaryList');
  if(!box) return;
  box.innerHTML = GLOSSARY.map(g => `
    <details class="gloss-item">
      <summary>${g.term}</summary>
      <p>${g.def}</p>
    </details>`).join('');
}

function renderGuide(){
  const box = document.getElementById('guideBox');
  if(!box) return;
  const g = TEACHER_GUIDE[state.tier];
  box.innerHTML = `
    <div class="guide-block">
      <h3>💬 Sohbet Soruları</h3>
      <ul>${g.questions.map(q=>`<li>${q}</li>`).join('')}</ul>
    </div>
    <div class="guide-block">
      <h3>✏️ Etkinlik Önerileri</h3>
      <ul>${g.activities.map(a=>`<li>${a}</li>`).join('')}</ul>
    </div>`;
}

function renderVideos(){
  const box = document.getElementById('videoGrid');
  if(!box) return;
  const tierName = TIERS.find(t=>t.id===state.tier).short;
  box.innerHTML = VIDEO_LESSONS.map(v => `
    <div class="video-card">
      <div class="video-thumb"><div class="play">▶</div></div>
      <div class="video-body">
        <h4>${v.title}</h4>
        <p>${v.desc}</p>
        <span class="video-tag">${TIERS.find(t=>t.id===v.tier).short} · ${v.dur}</span>
      </div>
    </div>`).join('');
}

/* ---------- MAP (illustrated, clickable) ---------- */
function renderMap(){
  const svg = document.getElementById('mapSvg');
  if(!svg) return;
  const hotspots = TOUR.map(t => `
    <g class="map-hotspot" tabindex="0" role="button" aria-label="${t.name}" onclick="showMapSpot('${t.id}')" onkeypress="if(event.key==='Enter')showMapSpot('${t.id}')">
      <circle cx="${t.map.x}" cy="${t.map.y}" r="9" fill="var(--terracotta)" stroke="#fff" stroke-width="2"/>
      <text x="${t.map.x}" y="${t.map.y+4}" text-anchor="middle" font-size="10" fill="#fff">${t.icon}</text>
    </g>`).join('');
  svg.innerHTML = document.getElementById('mapBase').innerHTML + hotspots;
  showMapSpot(TOUR[0].id);
}
function showMapSpot(id){
  const t = TOUR.find(x=>x.id===id);
  const pop = document.getElementById('mapPop');
  if(!pop || !t) return;
  pop.innerHTML = `<h4>${t.icon} ${t.name}</h4><p>${t.text[state.tier]}</p>`;
}

/* ---------- GAMES: QUIZ ---------- */
function setGame(g){
  state.game = g;
  ['quiz','memory','tf'].forEach(id=>{
    const btn = document.getElementById('gt-'+id);
    if(btn) btn.classList.toggle('active', g===id);
  });
  renderGameArea();
}
function renderGameArea(){
  if(state.game==='quiz'){ state.quizIndex=0; state.quizAnswered=false; renderQuiz(); }
  else if(state.game==='tf'){ state.tfIndex=0; state.tfAnswered=false; renderTF(); }
  else{ renderMemorySetup(); }
}
function renderQuiz(){
  const list = QUIZ[state.tier];
  const q = list[state.quizIndex];
  const area = document.getElementById('gameArea');
  if(!area) return;
  if(!q){
    area.innerHTML = `<div class="quiz-box"><p class="quiz-result">🎉 Bu yaş grubunun sorularını bitirdin!</p>
      <button class="btn btn-primary" onclick="state.quizIndex=0; state.quizAnswered=false; renderQuiz();">Tekrar Oyna</button></div>`;
    return;
  }
  area.innerHTML = `
    <div class="quiz-box">
      <div class="quiz-progress">Soru ${state.quizIndex+1} / ${list.length}</div>
      <div class="quiz-q">${q.q}</div>
      <div id="quizOpts">${q.opts.map((opt,i)=>`<button class="quiz-opt" onclick="answerQuiz(${i})">${opt}</button>`).join('')}</div>
      <div id="quizFeedback"></div>
    </div>`;
}
function answerQuiz(i){
  if(state.quizAnswered) return;
  state.quizAnswered = true;
  const q = QUIZ[state.tier][state.quizIndex];
  const btns = document.querySelectorAll('#quizOpts .quiz-opt');
  btns.forEach((b,idx)=>{
    if(idx===q.correct) b.classList.add('correct');
    else if(idx===i) b.classList.add('wrong');
  });
  const fb = document.getElementById('quizFeedback');
  fb.innerHTML = (i===q.correct) ? `<p class="quiz-result">✅ Doğru!</p>` : `<p class="quiz-result">❌ Doğru cevap işaretlendi.</p>`;
  if(i===q.correct) addStar();
  fb.innerHTML += `<button class="btn btn-primary" style="margin-top:10px;" onclick="nextQuiz()">Sonraki Soru</button>`;
}
function nextQuiz(){ state.quizIndex++; state.quizAnswered = false; renderQuiz(); }

/* ---------- GAMES: TRUE / FALSE ---------- */
function renderTF(){
  const list = TRUE_FALSE[state.tier];
  const item = list[state.tfIndex];
  const area = document.getElementById('gameArea');
  if(!area) return;
  if(!item){
    area.innerHTML = `<div class="tf-box"><p class="quiz-result">🎉 Doğru/Yanlış turunu bitirdin!</p>
      <button class="btn btn-primary" onclick="state.tfIndex=0; state.tfAnswered=false; renderTF();">Tekrar Oyna</button></div>`;
    return;
  }
  area.innerHTML = `
    <div class="tf-box">
      <div class="quiz-progress">İfade ${state.tfIndex+1} / ${list.length}</div>
      <div class="quiz-q">${item.s}</div>
      <div class="tf-btns">
        <button class="tf-btn" id="tfTrue" onclick="answerTF(true)">Doğru</button>
        <button class="tf-btn" id="tfFalse" onclick="answerTF(false)">Yanlış</button>
      </div>
      <div id="tfFeedback"></div>
    </div>`;
}
function answerTF(val){
  if(state.tfAnswered) return;
  state.tfAnswered = true;
  const item = TRUE_FALSE[state.tier][state.tfIndex];
  document.getElementById(item.a ? 'tfTrue':'tfFalse').classList.add('correct');
  if(val !== item.a) document.getElementById(val ? 'tfTrue':'tfFalse').classList.add('wrong');
  else addStar();
  const fb = document.getElementById('tfFeedback');
  fb.innerHTML = `<button class="btn btn-primary" style="margin-top:14px;" onclick="nextTF()">Sonraki</button>`;
}
function nextTF(){ state.tfIndex++; state.tfAnswered = false; renderTF(); }

/* ---------- GAMES: MEMORY MATCH ---------- */
function renderMemorySetup(){
  let cards = MEMORY_PAIRS.concat(MEMORY_PAIRS.map(p=>({id:p.id, icon:p.icon})));
  cards = cards.map(c=>({...c, key: Math.random()})).sort((a,b)=>a.key-b.key);
  state.memCards = cards; state.memFlipped = []; state.memMatched = []; state.memLock = false;
  renderMemory();
}
function renderMemory(){
  const area = document.getElementById('gameArea');
  if(!area) return;
  area.innerHTML = `<div class="memory-grid" id="memGrid"></div><div class="mem-status" id="memStatus">Eşleşen çift yok, hadi başlayalım!</div>`;
  const grid = document.getElementById('memGrid');
  grid.innerHTML = state.memCards.map((c,idx)=>{
    const flipped = state.memFlipped.includes(idx) || state.memMatched.includes(idx);
    return `<button class="mem-card ${flipped?'flipped':''} ${state.memMatched.includes(idx)?'matched':''}" onclick="flipCard(${idx})">${flipped?c.icon:'?'}</button>`;
  }).join('');
}
function flipCard(idx){
  if(state.memLock) return;
  if(state.memFlipped.includes(idx) || state.memMatched.includes(idx)) return;
  state.memFlipped.push(idx);
  renderMemory();
  if(state.memFlipped.length===2){
    state.memLock = true;
    const [a,b] = state.memFlipped;
    if(state.memCards[a].id === state.memCards[b].id){
      state.memMatched.push(a,b); state.memFlipped = []; state.memLock = false;
      addStar(); renderMemory();
      if(state.memMatched.length === state.memCards.length) document.getElementById('memStatus').textContent = '🎉 Tebrikler, tüm çiftleri buldun!';
    } else {
      setTimeout(()=>{ state.memFlipped = []; state.memLock = false; renderMemory(); }, 800);
    }
  }
}

/* ---------- SUPPORT / DONATE BUTTON ---------- */
function applySupportLink(){
  document.querySelectorAll('.support-btn').forEach(b => { b.href = SUPPORT_URL; });
}

/* ---------- BOOT HELPER (called at bottom of every page) ---------- */
function bootPage(pageId, renderFn){
  window.renderPageContent = renderFn;
  buildTierPicker();
  applySupportLink();
  markVisited(pageId);
  if(renderFn) renderFn();
  renderProgress();
}
