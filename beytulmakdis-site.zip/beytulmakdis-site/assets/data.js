/* ===========================================================
   Beytülmakdis Yolculuğu — Paylaşılan İçerik Verisi
   =========================================================== */
/* Buy Me a Coffee / Ko-fi gibi bir destek sayfası açtığında linkini
   SADECE burada değiştir — tüm sayfalardaki "Bizi Destekle" butonu otomatik güncellenir. */
const SUPPORT_URL = "https://www.buymeacoffee.com/kullaniciadin";

const TIERS = [
  {id:'k', label:'4-6 Yaş', short:'Yavrular', emoji:'🐣'},
  {id:'c', label:'6-12 Yaş', short:'Kâşifler', emoji:'🧭'},
  {id:'t', label:'12-16 Yaş', short:'Gençler', emoji:'📖'},
  {id:'y', label:'16-18 Yaş', short:'Genç Yetişkinler', emoji:'🎓'}
];

const NAV_PAGES = [
  {id:'home', label:'Ana Sayfa', href:'index.html'},
  {id:'history', label:'Tarih Yolculuğu', href:'tarih.html'},
  {id:'tour', label:'Aksa Turu & Harita', href:'tur.html'},
  {id:'prophets', label:'Peygamberler', href:'peygamberler.html'},
  {id:'games', label:'Oyunlar', href:'oyunlar.html'},
  {id:'stories', label:'Hikayeler', href:'hikayeler.html'},
  {id:'glossary', label:'Sözlük', href:'sozluk.html'},
  {id:'coloring', label:'Boyama', href:'boyama.html'},
  {id:'videos', label:'Video Dersler', href:'videolar.html'},
  {id:'guide', label:'Ebeveyn & Öğretmen', href:'rehber.html'}
];

const HOME_TEXT = {
  k:{h:`Haydi Beytülmakdis'i keşfedelim!`, l:`Renkli resimlerle ve kolay hikayelerle güzel bir yeri tanıyacağız.`},
  c:{h:`Beytülmakdis'i birlikte keşfedelim`, l:`Tarihini, peygamberlerle bağını ve mimarisini eğlenceli bir gezintiyle öğren.`},
  t:{h:`Beytülmakdis'in izinde bir yolculuk`, l:`Tarih, mimari ve inanç açısından bu özel şehri daha derinlemesine incele.`},
  y:{h:`Beytülmakdis: Ortak bir mirasın izinde`, l:`Tarihsel katmanları, dini önemi ve mimari mirası eleştirel bir bakışla keşfet.`}
};

const HISTORY = [
  {year:'MÖ 10. yy', icon:'🏛️', title:`Hz. Süleyman ve İlk Mabet`, text:{
    k:`Çok çok eskiden, Hz. Süleyman burada güzel bir mabet yaptırdı.`,
    c:`Hz. Süleyman (a.s.), Allah'ın kendisine verdiği güç ve hikmetle Beytülmakdis'te büyük ve görkemli bir mabet inşa ettirdi. Burası insanların ibadet ettiği kutsal bir yer oldu.`,
    t:`Kur'an'da bilgelik ve adaletiyle anılan Hz. Süleyman (a.s.), babası Hz. Davud'un (a.s.) başlattığı işi tamamlayarak Beytülmakdis'te tarihe geçen bir mabet inşa ettirdi. Bu yapı sonraki yüzyıllar boyunca bölgenin en önemli ibadet merkezlerinden biri oldu.`,
    y:`Hz. Süleyman'ın (a.s.) MÖ 10. yüzyılda inşa ettirdiği mabet, hem dini hem siyasi açıdan bölgenin merkezi konumunu pekiştirdi. Bu dönem, Beytülmakdis'in üç semavi din için de kutsal sayılmasının temellerinden birini oluşturur.`
  }},
  {year:'637', icon:'🕊️', title:`Hz. Ömer ve Fetih`, text:{
    k:`Yıllar sonra Müslümanlar bu şehri barışla aldılar.`,
    c:`Halife Hz. Ömer (r.a.), Kudüs'e geldiğinde şehir halkına adaletle ve hoşgörüyle davrandı. Herkesin inancına saygı gösterdi.`,
    t:`637'de İslam ordularının Kudüs'ü fethetmesinin ardından Hz. Ömer (r.a.) bizzat şehre geldi. Hristiyan din adamlarıyla yaptığı antlaşmayla halkın can, mal ve inanç güvenliğini garanti altına aldı.`,
    y:`Hz. Ömer'in (r.a.) 637'deki fethi, askeri zaferden öte bir yönetim anlayışı ortaya koyar. "Ömer Ahdi", gayrimüslim halkın ibadet özgürlüğünü ve mülkiyet haklarını güvence altına almıştır.`
  }},
  {year:'691', icon:'🕌', title:`Kubbetü's-Sahra'nın Yapılışı`, text:{
    k:`Altın renkli, çok güzel kubbeli bir yapı inşa edildi.`,
    c:`Emevi halifesi Abdülmelik, 691'de altın rengi kubbesiyle ünlü Kubbetü's-Sahra'yı yaptırdı. Bu yapı İslam mimarisinin en güzel örneklerinden biri oldu.`,
    t:`Emevi Halifesi Abdülmelik bin Mervan, 691'de Kubbetü's-Sahra'nın inşasını tamamlattı. Yapı, içindeki kayanın Miraç yolculuğuyla ilişkilendirilmesi sebebiyle özel öneme sahiptir.`,
    y:`691'de tamamlanan Kubbetü's-Sahra, dini olduğu kadar siyasi bir mesaj da taşıyordu. Mimari üslubu, Bizans ve Sasani geleneklerinin İslami bir sentezle yeniden yorumlanmasını yansıtır.`
  }},
  {year:'1187', icon:'🛡️', title:`Selahaddin Eyyubi Dönemi`, text:{
    k:`Selahaddin, şehri yeniden Müslümanlara kazandırdı.`,
    c:`1187'de Selahaddin Eyyubi, Kudüs'ü fethetti. O da Hz. Ömer gibi şehir halkına adil ve merhametli davrandı.`,
    t:`Haçlı Seferleri sırasında bir süre elden çıkan Kudüs, 1187'de Selahaddin Eyyubi tarafından yeniden fethedildi. Selahaddin şehir halkına af ve merhamet gösterdi.`,
    y:`Selahaddin'in 1187'de Kudüs'ü yeniden ele geçirmesi, fetih sonrası af politikasıyla 1099 işgalinin şiddet dolu tablosuyla sıkça karşılaştırılır.`
  }},
  {year:'16. yy', icon:'🏰', title:`Osmanlı Dönemi`, text:{
    k:`Osmanlılar şehri güzelleştirdi ve korudu.`,
    c:`Kanuni Sultan Süleyman, Kudüs'ün surlarını yeniden yaptırdı ve şehir dört asır boyunca özenle korundu.`,
    t:`Osmanlı, 1517'den itibaren yaklaşık 400 yıl Kudüs'ü yönetti. Kanuni döneminde surlar yeniden inşa edildi, çeşmeler ve su kemerleri yapıldı.`,
    y:`Osmanlı yönetimi (1517-1917) altında Kudüs, "millet sistemi" çerçevesinde farklı dini toplulukların özerk yönetildiği bir şehir oldu.`
  }},
  {year:'Günümüz', icon:'🌍', title:`Günümüz`, text:{
    k:`Bugün de Mescid-i Aksa, dünyadaki Müslümanlar için çok kıymetli bir yer.`,
    c:`Bugün Mescid-i Aksa, İslam'ın üç kutsal mescidinden biri olarak kabul edilir ve milyonlarca Müslüman için manevi değer taşır.`,
    t:`Günümüzde Mescid-i Aksa, Mekke ve Medine'den sonra İslam'ın üçüncü kutsal mescidi kabul edilir.`,
    y:`Mescid-i Aksa bugün, dini önemi kadar bölgesel gündemde de sıkça yer alır. Bu sitede önceliği tarihi, mimari ve manevi mirasa veriyoruz; güncel meseleler ayrı, dengeli kaynaklarla ele alınmalıdır.`
  }}
];

const PROPHETS = [
  {icon:'🌟', name:'Hz. İbrahim (a.s.)', text:{
    k:`Hz. İbrahim, Allah'ı çok seven iyi bir insandı.`,
    c:`Hz. İbrahim (a.s.), Allah'a olan güveniyle tanınan bir peygamberdir. Üç büyük dinin ortak atası kabul edilir.`,
    t:`Hz. İbrahim (a.s.), tevhid inancının öncülerinden biridir. Bu topraklarda yaşadığına inanılır; miras onunla özdeşleşmiştir.`,
    y:`Hz. İbrahim (a.s.), İslam, Hristiyanlık ve Yahudilik'te "Halilullah" olarak anılan, üç dinin de atıfta bulunduğu ortak bir figürdür.`
  }},
  {icon:'👑', name:'Hz. Davud (a.s.)', text:{
    k:`Hz. Davud çok güzel sesle dua ederdi.`,
    c:`Hz. Davud (a.s.), hem güçlü bir kral hem de güzel sesiyle Allah'a hamd eden bir peygamberdi.`,
    t:`Hz. Davud (a.s.), Kur'an'da adaleti ve Allah'a bağlılığıyla anılır. Kudüs'ü başkent yaptığı rivayet edilir.`,
    y:`Hz. Davud (a.s.) döneminde Kudüs, siyasi ve dini bir merkez olmaya başladı; bu ortak anlatı şehrin çok katmanlı kutsallığının temellerinden biridir.`
  }},
  {icon:'🕊️', name:'Hz. Süleyman (a.s.)', text:{
    k:`Hz. Süleyman, kuşlarla ve rüzgârla konuşabilen bilge bir peygamberdi.`,
    c:`Hz. Süleyman (a.s.), Allah'ın kendisine verdiği hikmet ve güçle tanınır.`,
    t:`Hz. Süleyman (a.s.), Kur'an'da hem büyük bir hükümdar hem derin bir hikmet sahibi peygamber olarak tasvir edilir.`,
    y:`Hz. Süleyman'ın (a.s.) hükümdarlığı, hem maddi güç hem manevi bilgeliğin bir arada temsil edildiği istisnai bir örnektir.`
  }},
  {icon:'💚', name:'Hz. İsa (a.s.)', text:{
    k:`Hz. İsa da bu topraklarda yaşamış sevgi dolu bir peygamberdi.`,
    c:`Hz. İsa (a.s.), Beytülmakdis ve çevresinde yaşamış, sevgi ve merhameti öğütlemiş bir peygamberdir.`,
    t:`Hz. İsa'nın (a.s.) doğumu ve yaşamı Filistin topraklarıyla iç içe geçmiştir; bölgenin kutsallığına ayrı bir katman ekler.`,
    y:`Hz. İsa'nın (a.s.) hayatı, Beytülmakdis'in Hristiyanlık için de kutsal kabul edilmesinin temel sebebidir.`
  }},
  {icon:'✨', name:'Hz. Muhammed (s.a.v.)', text:{
    k:`Peygamberimiz bir gece mucizevi şekilde bu kutsal yeri ziyaret etti.`,
    c:`Peygamberimiz, İsra gecesinde Mekke'den Mescid-i Aksa'ya, oradan da göklere (Miraç) yolculuk etti.`,
    t:`İsra ve Miraç mucizesinde Hz. Muhammed (s.a.v.), bir gecede Mescid-i Haram'dan Mescid-i Aksa'ya götürülmüş, oradan göklere yükselmiştir.`,
    y:`İsra ve Miraç, Mescid-i Aksa'nın İslam inancındaki merkezi konumunu teolojik olarak temellendiren en önemli anlatıdır.`
  }}
];

const TOUR = [
  {id:'kubbe', icon:'🕌', name:`Kubbetü's-Sahra`, map:{x:200,y:120}, text:{
    k:`Altın rengi parlayan yuvarlak bir kubbe! İçinde büyük bir kaya var.`,
    c:`Kubbetü's-Sahra, altın rengi kubbesiyle Kudüs'ün en tanınan yapısıdır.`,
    t:`Kubbetü's-Sahra, sekizgen planı ve mozaikleriyle erken dönem İslam mimarisinin en önemli örneklerinden biridir. 691'de tamamlanmıştır.`,
    y:`Kubbetü's-Sahra'nın mimarisi Bizans kilise mimarisinden ilham alırken, kufi yazıtlarla güçlü bir İslami kimlik ortaya koyar.`
  }},
  {id:'kible', icon:'🕋', name:'Kıble Mescidi', map:{x:200,y:260}, text:{
    k:`Burada insanlar namaz kılar, gümüş kubbesi çok güzeldir.`,
    c:`Kıble Mescidi, gümüş rengi kubbesiyle bilinen ana ibadet salonudur.`,
    t:`Gümüş kubbeli Kıble Mescidi, Mescid-i Aksa külliyesinin asıl ibadet binasıdır.`,
    y:`Kıble Mescidi, farklı dönemlerde (Emevi, Eyyubi, Memluk, Osmanlı) yapılan onarımlarla bugünkü hâlini almıştır.`
  }},
  {id:'avlu', icon:'🏞️', name:'Avlular ve Revaklar', map:{x:90,y:190}, text:{
    k:`Geniş taş avlularda çocuklar koşup oynayabilir.`,
    c:`Mescid-i Aksa'nın geniş taş avluları, ziyaretçilerin gezinip dinlenebileceği alanlardır.`,
    t:`35 hektarlık külliye alanındaki avlular, hem ibadet hem eğitim amacıyla kullanılmıştır.`,
    y:`Haremü'ş-Şerif olarak bilinen bu alan, medrese, kütüphane ve toplumsal buluşma noktası işlevi de görmüştür.`
  }},
  {id:'zeytin', icon:'🫒', name:'Zeytin Ağaçları', map:{x:310,y:190}, text:{
    k:`Yeşil zeytin ağaçları, kuşlar ve çiçekler her yeri güzelleştirir.`,
    c:`Külliyenin çevresinde yüzlerce yıllık zeytin ağaçları bulunur.`,
    t:`Bölgedeki zeytin ağaçları hem ekonomik hem sembolik öneme sahiptir; Kur'an'da da zeytine atıfta bulunulur.`,
    y:`Zeytin ağacı Kur'an'da "ne doğuya ne batıya ait" mübarek bir ağaç olarak nitelenir.`
  }},
  {id:'kapi', icon:'🗝️', name:'Kapılar ve Surlar', map:{x:200,y:40}, text:{
    k:`Şehrin etrafında büyük taş kapılar ve duvarlar vardır.`,
    c:`Kudüs'ün etrafını çevreleyen surlarda birçok tarihi kapı bulunur.`,
    t:`Kanuni Sultan Süleyman döneminde yeniden inşa edilen surlar, eski şehir dokusunu çevreler.`,
    y:`16. yüzyılda inşa edilen Osmanlı surları, savunma amaçlı ve sembolik sınır belirleyici yapılar olarak işlev görmüştür.`
  }}
];

const STORIES = {
  k:{title:`Küçük Kâşif ve Zeytin Ağacı`, text:`Küçük Ayşe bir gün büyükannesiyle bahçedeki zeytin ağacının altına oturdu. Büyükannesi ona, çok uzaklarda, Beytülmakdis denilen çok özel bir yerde de böyle güzel zeytin ağaçları olduğunu anlattı. Ayşe, o ağaçların altında peygamberlerin yürüdüğünü duyunca gözleri parladı. "Ben de büyüyünce oraya gitmek istiyorum!" dedi. Büyükannesi gülümsedi: "O zaman şimdiden sevgiyle öğrenmeye başla." O günden sonra Ayşe her zeytin ağacı gördüğünde Beytülmakdis'i hatırladı ve içi sevgiyle doldu.`},
  c:{title:`Dedenin Fotoğraf Albümü`, text:`Mert, dedesinin evinde eski bir fotoğraf albümü buldu. İçinde altın kubbeli bir caminin resmi vardı. "Dede, bu neresi?" diye sordu. Dedesi gülümsedi: "Burası Mescid-i Aksa, evladım. Peygamberimizin bir gecede Mekke'den oraya, oradan da göklere yükseldiği kutsal bir yer." Mert dinledikçe merakı büyüdü; Hz. Süleyman'ı, Hz. Ömer'in adaletini, Selahaddin'in merhametini öğrendi. O gece yatağına yattığında, hiç görmediği ama artık kalbinde yer eden bu şehri düşünerek uykuya daldı.`},
  t:{title:`Zeynep'in Projesi`, text:`Zeynep, okulda hazırladığı proje için Beytülmakdis tarihini araştırıyordu. Kaynaklarda okudukça fark etti ki bu şehir, yüzyıllar boyunca kuşatmalar, fetihler ve yeniden inşalar görmüş; ama her defasında insanlar oraya olan bağlılıklarını korumuş. Selahaddin'in şehri aldığında düşmanlarına gösterdiği merhameti okuyunca derinden etkilendi. "Demek ki güç, insana zulmetme hakkı değil, adaletle davranma sorumluluğu veriyor" diye düşündü. Sunumunda arkadaşlarına sadece tarihi değil, bu dersi de anlattı.`},
  y:{title:`Elif'in Sorusu`, text:`Elif, üniversitede bir sunum hazırlarken Beytülmakdis'in üç din için de kutsal sayılmasının nedenlerini araştırdı. Hz. İbrahim'den Hz. Muhammed'e uzanan peygamberler zincirinin bu toprakları nasıl ortak bir mirasa dönüştürdüğünü fark etti. Sunumunun sonunda arkadaşlarına şunu sordu: "Ortak bir mirası paylaşmak, bizi birbirimize düşman mı yoksa daha anlayışlı mı yapmalı?" Bu soru sınıfta uzun bir sohbetin kapısını araladı.`}
};

const QUIZ = {
  k:[
    {q:`Peygamberimiz İsra gecesinde nereye gitti?`, opts:[`Mescid-i Aksa'ya`,`Ormana`,`Denize`], correct:0},
    {q:`Kubbetü's-Sahra'nın rengi nedir?`, opts:[`Mavi`,`Altın`,`Kırmızı`], correct:1},
    {q:`Hz. Süleyman hangi hayvanlarla konuşabiliyordu?`, opts:[`Balıklarla`,`Aslanlarla`,`Kuşlarla`], correct:2},
    {q:`Beytülmakdis'te hangi ağaç çok bulunur?`, opts:[`Çam`,`Zeytin`,`Muz`], correct:1}
  ],
  c:[
    {q:`Mescid-i Aksa İslam'da kaçıncı kutsal mesciddir?`, opts:[`Birinci`,`İkinci`,`Üçüncü`], correct:2},
    {q:`Kubbetü's-Sahra'yı hangi halife yaptırdı?`, opts:[`Hz. Ömer`,`Abdülmelik bin Mervan`,`Kanuni Sultan Süleyman`], correct:1},
    {q:`637 yılında Kudüs'ü hangi halife fethetti?`, opts:[`Hz. Ebubekir`,`Hz. Ömer`,`Hz. Ali`], correct:1},
    {q:`1187'de Kudüs'ü kim yeniden fethetti?`, opts:[`Selahaddin Eyyubi`,`Kanuni Sultan Süleyman`,`Fatih Sultan Mehmed`], correct:0}
  ],
  t:[
    {q:`İsra ve Miraç olayı hangi surede anlatılır?`, opts:[`Bakara`,`İsra`,`Fatiha`], correct:1},
    {q:`Kanuni Sultan Süleyman Kudüs'te neyi yeniden inşa ettirdi?`, opts:[`Surları`,`Limanı`,`Havaalanını`], correct:0},
    {q:`Kubbetü's-Sahra hangi yüzyılda tamamlandı?`, opts:[`5. yüzyıl`,`7. yüzyıl`,`12. yüzyıl`], correct:1},
    {q:`Hz. Ömer'in Kudüs halkıyla yaptığı antlaşma ne olarak bilinir?`, opts:[`Ömer Ahdi`,`Medine Sözleşmesi`,`Hudeybiye Antlaşması`], correct:0}
  ],
  y:[
    {q:`Kubbetü's-Sahra'nın mimarisi hangi geleneklerden ilham almıştır?`, opts:[`Çin ve Hint`,`Bizans ve Sasani`,`Maya ve Aztek`], correct:1},
    {q:`Osmanlı'nın Kudüs'teki "millet sistemi" neyi ifade eder?`, opts:[`Tek dinli zorunlu yönetim`,`Farklı dini toplulukların özerk yönetimi`,`Askeri sıkıyönetim`], correct:1},
    {q:`İsra suresinin açılışında bölge için kullanılan ifade nedir?`, opts:[`Issız topraklar`,`Uzak diyarlar`,`Çevresini mübarek kıldığımız`], correct:2},
    {q:`Zeytin ağacı Kur'an'da nasıl tanımlanır?`, opts:[`Çölün bitkisi`,`Ne doğuya ne batıya ait mübarek ağaç`,`Denizin meyvesi`], correct:1}
  ]
};

const TRUE_FALSE = {
  k:[
    {s:`Mescid-i Aksa'nın rengi altındır.`, a:true},
    {s:`Beytülmakdis'te hiç ağaç yoktur.`, a:false},
    {s:`Peygamberimiz Mescid-i Aksa'ya gitti.`, a:true}
  ],
  c:[
    {s:`Hz. Ömer, Kudüs halkına kötü davrandı.`, a:false},
    {s:`Kubbetü's-Sahra 691 yılında yapıldı.`, a:true},
    {s:`Selahaddin Eyyubi Kudüs'ü 1187'de fethetti.`, a:true},
    {s:`Mescid-i Aksa İslam'ın ilk kutsal mescididir.`, a:false}
  ],
  t:[
    {s:`Kanuni Sultan Süleyman Kudüs surlarını yeniden yaptırdı.`, a:true},
    {s:`İsra ve Miraç, Bakara suresinde anlatılır.`, a:false},
    {s:`Ömer Ahdi, halkın inanç güvenliğini garanti etti.`, a:true},
    {s:`Osmanlılar Kudüs'ü hiç yönetmedi.`, a:false}
  ],
  y:[
    {s:`Kubbetü's-Sahra mimarisi Bizans ve Sasani etkisi taşır.`, a:true},
    {s:`Millet sistemi, tek bir dinin zorunlu kılınmasıdır.`, a:false},
    {s:`Zeytin ağacı Kur'an'da mübarek bir ağaç olarak geçer.`, a:true},
    {s:`Beytülmakdis sadece İslam için kutsaldır.`, a:false}
  ]
};

const MEMORY_PAIRS = [
  {id:'kubbe', icon:'🕌'}, {id:'zeytin', icon:'🫒'}, {id:'tarih', icon:'📜'},
  {id:'baris', icon:'🕊️'}, {id:'yildiz', icon:'⭐'}, {id:'kapi', icon:'🗝️'}
];

const GLOSSARY = [
  {term:`Beytülmakdis`, def:`"Kutsal/temiz ev" anlamına gelir; Kudüs şehri ve Mescid-i Aksa külliyesi için kullanılan İslami bir isimdir.`},
  {term:`Mescid-i Aksa`, def:`Kelime anlamı "en uzak mescit"tir. Kudüs'teki külliyenin tamamını, hem Kıble Mescidi'ni hem Kubbetü's-Sahra'yı ve avluları kapsar.`},
  {term:`Kubbetü's-Sahra`, def:`691 yılında tamamlanan, altın rengi kubbesiyle bilinen, içinde kutsal kayayı barındıran anıt yapı.`},
  {term:`İsra`, def:`Hz. Muhammed'in (s.a.v.) bir gecede Mekke'den Kudüs'e yaptığı mucizevi yolculuğun adı.`},
  {term:`Miraç`, def:`İsra yolculuğunun devamında Hz. Peygamber'in (s.a.v.) Kudüs'ten göklere yükselmesi.`},
  {term:`Kıble`, def:`Namaz kılarken yönelinen yön. İlk yıllarda Müslümanların kıblesi Kudüs'tü, sonra Kâbe'ye çevrildi.`},
  {term:`Külliye`, def:`Bir ana yapı etrafında toplanan cami, medrese, avlu gibi yapılar bütünü.`},
  {term:`Sahabe`, def:`Hz. Muhammed'i (s.a.v.) görmüş ve iman etmiş kişilere verilen isim; Hz. Ömer de bir sahabidir.`},
  {term:`Halife`, def:`Hz. Peygamber'den sonra Müslümanların dini ve siyasi liderliğini üstlenen kişi.`},
  {term:`Minare`, def:`Camilerde ezanın okunduğu, genelde ince ve uzun kule biçimindeki yapı.`},
  {term:`Mihrap`, def:`Camide imamın namaz kıldırırken durduğu, kıble yönünü gösteren girinti.`},
  {term:`Vakıf`, def:`Bir kişinin mal veya mülkünü kamu yararına, kalıcı olarak bağışlamasıyla oluşan kurum; Kudüs'te birçok yapı vakıflarla ayakta kalmıştır.`}
];

const TEACHER_GUIDE = {
  k:{
    questions:[`Zeytin ağacı sana neyi hatırlatıyor?`, `Peygamberimizin gittiği o güzel yer nasıl bir yerdi sence?`],
    activities:[`Zeytin ağacı boyama sayfasını birlikte boyayın.`, `Basit bir kubbe şekli keserek küçük bir maket yapın.`, `"Beytülmakdis" kelimesini hecelerine ayırıp tekrar edin.`]
  },
  c:{
    questions:[`Hz. Ömer'in Kudüs halkına davranışından ne öğreniyoruz?`, `Sence bir şehir neden birden fazla din için kutsal olabilir?`],
    activities:[`Zaman tüneli sayfasındaki olayları kartlara yazıp kronolojik sıraya dizin.`, `Çocuklardan Mescid-i Aksa'yı hayal ederek resim çizmelerini isteyin.`, `Sözlük sayfasındaki terimlerle küçük bir bulmaca hazırlayın.`]
  },
  t:{
    questions:[`Selahaddin Eyyubi'nin af politikası neden önemli bir örnektir?`, `Kubbetü's-Sahra'nın mimarisi hangi kültürlerden izler taşır?`],
    activities:[`Öğrencilerden bir dönemi (Emevi, Eyyubi, Osmanlı) seçip kısa bir sunum hazırlamalarını isteyin.`, `Tarih Yolculuğu sayfasını kullanarak bir "zaman çizelgesi" posteri hazırlatın.`, `Sınıfta "adalet ve güç" temalı bir tartışma başlatın.`]
  },
  y:{
    questions:[`Beytülmakdis'in üç din için de kutsal sayılması ne anlama gelir?`, `Tarihsel anlatılar ile güncel algı arasındaki farkları nasıl değerlendirirsin?`],
    activities:[`Öğrencilerden farklı dönemlerin (Emevi, Haçlı, Eyyubi, Osmanlı) yönetim anlayışlarını karşılaştıran kısa bir makale yazmalarını isteyin.`, `"Ortak miras" kavramı üzerine küçük grup tartışmaları düzenleyin.`, `Mimari üslupların (Bizans, Sasani, İslami) nasıl harmanlandığını araştırma ödevi olarak verin.`]
  }
};

const VIDEO_LESSONS = [
  {title:`Beytülmakdis Nedir? (Giriş)`, tier:'k', dur:'3 dk', desc:`En küçük kâşitlerimiz için resimli, basit bir tanıtım.`},
  {title:`İsra ve Miraç Hikayesi`, tier:'c', dur:'6 dk', desc:`Peygamberimizin mucizevi gece yolculuğu, çocuklara uygun anlatımla.`},
  {title:`Kubbetü's-Sahra'nın Mimarisi`, tier:'t', dur:'9 dk', desc:`Yapının tarihi ve mimari detaylarına daha yakından bakış.`},
  {title:`Üç Din, Ortak Bir Miras`, tier:'y', dur:'12 dk', desc:`Beytülmakdis'in çok katmanlı kutsallığı üzerine analitik bir anlatım.`},
  {title:`Selahaddin Eyyubi ve Adalet`, tier:'t', dur:'8 dk', desc:`1187 fethi ve sonrasındaki af politikasının hikayesi.`},
  {title:`Zeytin Ağacının Hikayesi`, tier:'k', dur:'2 dk', desc:`Zeytin ağacının bereket ve barışla ilişkisini anlatan kısa bir video.`}
];

const COLORING_PAGES = [
  {id:'dome', title:'Kubbetü\'s-Sahra'},
  {id:'lantern', title:'Fener'},
  {id:'olive', title:'Zeytin Dalı'},
  {id:'star', title:'Sekiz Köşeli Yıldız'},
  {id:'gate', title:'Taş Kapı'},
  {id:'mosque', title:'Cami Silüeti'}
];
